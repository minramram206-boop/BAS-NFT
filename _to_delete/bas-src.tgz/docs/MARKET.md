# BAS market (Phase F)

Status: design only. Nothing in this document is built, tested or deployed.
The decision record is D-0082 in `DECISIONS.md`.

## Goal

Owners can sell a citizen for SOL without moving anything by hand. A wallet
such as Solflare offers no Send for an unverified collection, so today the only
way to move a citizen is the devnet transfer script. D-0055 also expects
players who want more than one citizen to buy them on a secondary market.

The market trades this collection only. It is not a generic agent market
(SPEC 2.3), pays no points or tokens for trading, and promises no yield.

## Phases

| Phase | Scope | Holds funds or assets |
|---|---|---|
| F1 | Fixed-price listings: list, update price, cancel, buy | No |
| F2 | Offers: a buyer names a price, the owner accepts | SOL, until accepted or withdrawn |
| F3 | Auctions | SOL (bids), plus settlement by the worker |

F1 ships first. F2 and F3 hold other people's SOL, so they wait until F1 has
been exercised on devnet. Until an external audit, every phase stays on devnet.

## F1 design

A new Anchor program, `programs/market`, next to `district`. It reuses the
`district` crate's hand-written Core asset reader (`mpl_core`) instead of
copying it.

### Listing without custody

The asset never leaves the seller's wallet. To list, the seller adds the Core
`TransferDelegate` plugin to the asset with the market program's authority PDA
(`["market-authority"]`) as delegate, and creates a `Listing` account. Both
happen in one wallet-signed transaction. To buy, the program transfers the
asset as that delegate. If the seller moves the asset elsewhere first, Core
resets the delegate and the purchase fails, atomically, with nothing paid.

While listed the seller is still the owner, so chat, training and missions
keep working.

### Accounts

- `MarketConfig` (`["market-config"]`): admin, pending admin, collection,
  royalty bps, royalty recipient, fee bps, fee recipient, paused. Royalty
  values must equal the collection's Royalties plugin (500 bps). A devnet
  script checks that they match, because the program does not parse plugins.
- `Listing` (`["listing", asset]`): seller, asset, price in lamports, bump.
  One listing per asset.

### Instructions

- `initialize_config`, `set_paused`, `update_config`, `propose_admin` and
  `accept_admin`, following the pattern of `district`.
- `create_listing(price)`: seller signs. The asset must belong to the
  collection and be owned by the seller. The price must be at least the
  minimum (0.01 SOL, so the royalty never falls below rent for a new account).
- `update_price(price)`: seller signs, and the asset must still be theirs.
- `cancel_listing`: seller signs. The client bundles removal of the delegate in
  the same transaction. The listing rent goes back to the seller.
- `close_stale_listing`: anyone may call it when the asset is no longer owned
  by the listed seller. The rent goes to the seller.
- `buy(max_price)`: buyer signs. The program checks that it is not paused, that
  the asset is in the collection, that its owner equals `listing.seller`, that
  the buyer is not the seller, and that `listing.price <= max_price` (so a seller
  cannot raise the price after the buyer signed). Then, in one transaction:
  SOL to the seller, royalty to the royalty recipient, fee to the fee
  recipient (skipped when zero), a Core `TransferV1` CPI signed by the
  authority PDA, and the listing closed to the seller.
  `proceeds = price - royalty - fee`, all in integer lamports, rounded down.

### Why the royalty is enforced here only

The collection's Royalties plugin uses `ruleSet: None`, so other marketplaces
choose whether to honour it. This program always pays it. Whether to restrict
transfers on-chain with a rule set is a separate decision, because it can also
affect plain wallet transfers.

## Risks to prove, not assume

- The Core `TransferV1` instruction is built by hand (no `mpl-core` crate under
  Solana 1.18). Its discriminator, account order and the delegate reset on
  transfer must be asserted by an integration test that loads the real
  `mpl_core.so`, dumped from devnet with
  `solana program dump CoREENxT6tW1HoK8ypY1SxRMZTcVPm7R94rH4PZNhX7d mpl_core.so -u devnet`.
  The `district` tests build fake asset bytes and never run Core, so they are
  not enough here.
- Building the SBF binary and the devnet run need the Solana toolchain (WSL),
  as for `district`. Pure logic (price split, rounding, limits) can be
  unit-tested without it.
- Royalty and fee recipients must already exist as funded accounts, or a small
  transfer can fail on rent.

## Web and worker

- `/market`: active listings, read with `getProgramAccounts` filtered on the
  `Listing` discriminator (the supply is 100, so no indexer is needed). A
  listing is shown as buyable only when the asset owner still equals the seller
  and the delegate is present.
- Citizen profile: a List for sale action for the owner.
- A sale writes a line to the asset's public history through the existing
  worker path. Buying gives no credit, points or tokens.

## Order of work

1. Program crate and pure-logic unit tests.
2. Integration tests against the real `mpl_core.so` (run in WSL).
3. Client package for the instruction builders and listing reads.
4. Market page and the profile action.
5. Devnet end-to-end with wallet A and wallet B.
