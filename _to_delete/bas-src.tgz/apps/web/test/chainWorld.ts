import { createPrivateKey, sign } from 'node:crypto';
import { CORE_CANDY_GUARD_PROGRAM_ID, ROLE_TEMPLATES, INSTRUCTION_DISCRIMINATORS, type CitizenStateOnChain } from '@bas/chain-client';
import type { CitizenRecord } from '@bas/content';
import type { ChainReader, CitizenOnChain } from '@bas/mission-server';
import { Keypair, PublicKey, Transaction, TransactionInstruction } from '@solana/web3.js';
import type { Balances, ChainCitizen, DistrictReads, SaleReading, WalletSession } from '../src/lib/data/chain/types.ts';
import { WalletDeclinedError } from '../src/lib/data/chain/types.ts';
import type { SendRpc, SignatureStatus } from '../src/lib/data/chain/transactions.ts';

export const PROGRAM_ID = new PublicKey('82zccW1Z97ic24aCrt2c3U6qDUZMfbHufZMCjv2dm1Ym');
export const UTILITY_MINT = '6yv2K6n1pczbSdWNZGfEvkQuS5rgHhq5RwKD64PQ7TcG';
export const TOKEN_PROGRAM = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
export const SEASON_START = 1_800_000_000;
export const DAY = 86_400;
export const BASE_COST = 100_000_000n;

const same = (a: Uint8Array, b: Uint8Array): boolean => a.length === b.length && a.every((byte, index) => byte === b[index]);

interface FakeAsset {
  asset: string;
  owner: string;
  serial: number;
  scores: [number, number, number];
  credits: [number, number, number];
  registered: boolean;
}

/** The public sale in memory: citizens come out in `queue` order, like a draw that happened to be this one. */
export interface FakeSale {
  /** Serials still to be handed out, first one next. */
  queue: number[];
  /** Citizens the machine was created with. */
  total: number;
  /** Lamports one mint costs. */
  price: bigint;
  /** Mints one wallet may make. */
  limit: number;
  minted: Map<string, number>;
  /** Set while the sale is not loaded or the server is not allowed to build mints. */
  loaded: boolean;
}

/**
 * A small cluster in memory. It answers the mission server's reads and the web
 * app's reads, and it applies the transactions the app sends the way the
 * program would: signatures must verify, an upgrade needs a credit and tokens,
 * and a claim receipt can only be created once.
 */
export class World implements ChainReader, DistrictReads {
  readonly assets: FakeAsset[] = [];
  readonly receipts = new Set<string>();
  readonly tokens = new Map<string, bigint>();
  readonly sol = new Map<string, bigint>();
  /** Signatures of transactions that were applied, newest last. */
  readonly applied: string[] = [];
  /** Set to make the next reads fail, like a dropped connection. */
  down = false;
  /** The public sale, or `null` when the cluster has no Candy Machine. */
  sale_: FakeSale | null = null;
  /** Mint transactions the server built, by the asset they create. */
  readonly built: string[] = [];

  private readonly roster: readonly CitizenRecord[];
  private readonly nowSeconds: () => number;

  constructor(roster: readonly CitizenRecord[], nowSeconds: () => number) {
    this.roster = roster;
    this.nowSeconds = nowSeconds;
  }

  add(serial: number, owner: string, scores: [number, number, number], credits: [number, number, number] = [0, 0, 0], registered = true): string {
    const asset = Keypair.generate().publicKey.toBase58();
    this.assets.push({ asset, owner, serial, scores, credits, registered });
    return asset;
  }

  find(asset: string): FakeAsset {
    const found = this.assets.find((item) => item.asset === asset);
    if (!found) throw new Error(`no asset ${asset}`);
    return found;
  }

  transfer(asset: string, to: string): void {
    this.find(asset).owner = to;
  }

  // --- the mission server's view -------------------------------------------------

  async assetOwner(asset: string): Promise<string | null> {
    return this.assets.find((item) => item.asset === asset)?.owner ?? null;
  }

  async assetInfo(asset: string): Promise<{ owner: string; serial: number | null } | null> {
    const found = this.assets.find((item) => item.asset === asset);
    return found ? { owner: found.owner, serial: found.serial } : null;
  }

  async citizen(asset: string): Promise<CitizenOnChain | null> {
    const found = this.assets.find((item) => item.asset === asset);
    if (!found || !found.registered) return null;
    const role = ROLE_TEMPLATES.find((template) => template.key === this.roster.find((c) => c.id === found.serial)?.roleKey);
    return {
      citizenId: this.assets.indexOf(found) + 1,
      role: role?.index ?? 0,
      scores: { intelligence: found.scores[0], alignment: found.scores[1], compute: found.scores[2] },
    };
  }

  async claimReceiptExists(asset: string, missionChainId: number, nonce: number): Promise<boolean> {
    return this.receipts.has(`${asset}:${missionChainId}:${nonce}`);
  }

  async latestBlockhash(): Promise<{ blockhash: string; lastValidBlockHeight: number }> {
    return { blockhash: '11111111111111111111111111111111', lastValidBlockHeight: 1 };
  }

  // --- the web app's view --------------------------------------------------------

  async citizens(): Promise<readonly ChainCitizen[]> {
    if (this.down) throw new Error('connection dropped');
    return this.assets.map((item): ChainCitizen => {
      const role = ROLE_TEMPLATES.find((template) => template.key === this.roster.find((c) => c.id === item.serial)?.roleKey);
      const state: CitizenStateOnChain | null = item.registered
        ? {
            version: 1,
            bump: 255,
            citizenId: this.assets.indexOf(item) + 1,
            asset: item.asset,
            role: (role?.index ?? 0) as CitizenStateOnChain['role'],
            intelligence: item.scores[0],
            alignment: item.scores[1],
            compute: item.scores[2],
            insightTrainingCredits: item.credits[0],
            bondTrainingCredits: item.credits[1],
            craftTrainingCredits: item.credits[2],
          }
        : null;
      return { asset: item.asset, owner: item.owner, serial: item.serial, state };
    });
  }

  async sale(wallet: string | null): Promise<SaleReading | null> {
    if (this.down) throw new Error('connection dropped');
    const sale = this.sale_;
    if (!sale) return null;
    return {
      itemsAvailable: sale.total,
      itemsRedeemed: sale.total - sale.queue.length,
      mintedByWallet: wallet ? (sale.minted.get(wallet) ?? 0) : 0,
    };
  }

  /** What the mission server needs to build a mint: the sale state, and a transaction a wallet can sign. */
  mintBackend() {
    return {
      signer: 'fake-mint-signer',
      sale: async (wallet: string) => {
        const sale = this.sale_;
        if (!sale) return undefined;
        return {
          collection: 'collection',
          mintAuthority: 'guard',
          itemsAvailable: sale.total,
          itemsLoaded: sale.loaded ? sale.total : 0,
          itemsRedeemed: sale.total - sale.queue.length,
          mintedByWallet: sale.minted.get(wallet) ?? 0,
        };
      },
      prepare: async (wallet: string) => {
        const asset = Keypair.generate();
        const buyer = new PublicKey(wallet);
        const transaction = new Transaction({ feePayer: buyer, recentBlockhash: '11111111111111111111111111111111' });
        transaction.add(
          new TransactionInstruction({
            programId: new PublicKey(CORE_CANDY_GUARD_PROGRAM_ID),
            keys: [
              { pubkey: buyer, isSigner: true, isWritable: true },
              { pubkey: asset.publicKey, isSigner: true, isWritable: true },
            ],
            data: Buffer.alloc(0),
          }),
        );
        // The server's share of the signatures, like the asset keypair and the mint signer in the real transaction.
        transaction.partialSign(asset);
        this.built.push(asset.publicKey.toBase58());
        return {
          transaction: new Uint8Array(transaction.serialize({ requireAllSignatures: false, verifySignatures: false })),
          asset: asset.publicKey.toBase58(),
          blockhash: '11111111111111111111111111111111',
          lastValidBlockHeight: 1,
        };
      },
    };
  }

  async balances(owner: string): Promise<Balances> {
    if (this.down) throw new Error('connection dropped');
    return { solLamports: this.sol.get(owner) ?? 0n, tokenAtoms: this.tokens.get(owner) ?? 0n };
  }

  // --- transactions --------------------------------------------------------------

  /** Applies a signed transaction like the program would, or throws like a rejected one. */
  apply(bytes: Uint8Array): string {
    const transaction = Transaction.from(bytes);
    if (!transaction.verifySignatures()) throw new Error('a signature is missing or wrong');
    const [instruction] = transaction.instructions;
    if (instruction?.programId.toBase58() === CORE_CANDY_GUARD_PROGRAM_ID) return this.applyMint(transaction, instruction);
    if (transaction.instructions.length !== 1 || !instruction || !instruction.programId.equals(PROGRAM_ID)) {
      throw new Error('not a district transaction');
    }
    const data = new Uint8Array(instruction.data);
    const kind = same(data.subarray(0, 8), INSTRUCTION_DISCRIMINATORS.upgradeScore)
      ? 'upgrade'
      : same(data.subarray(0, 8), INSTRUCTION_DISCRIMINATORS.claimTrainingCredit)
        ? 'claim'
        : null;
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);

    if (kind === 'upgrade') {
      const asset = this.find(instruction.keys[1]!.pubkey.toBase58());
      const owner = instruction.keys[3]!;
      if (!owner.isSigner || owner.pubkey.toBase58() !== asset.owner) throw new Error('signer does not hold the asset');
      const stat = data[8]!;
      const cost = BASE_COST * BigInt(asset.scores[stat]! + 1);
      if (asset.credits[stat]! < 1) throw new Error('no credit');
      if ((this.tokens.get(asset.owner) ?? 0n) < cost) throw new Error('not enough tokens');
      this.tokens.set(asset.owner, (this.tokens.get(asset.owner) ?? 0n) - cost);
      asset.credits[stat]! -= 1;
      asset.scores[stat]! += 1;
    } else if (kind === 'claim') {
      const asset = this.find(instruction.keys[1]!.pubkey.toBase58());
      const owner = instruction.keys[4]!;
      if (!owner.isSigner || owner.pubkey.toBase58() !== asset.owner) throw new Error('signer does not hold the asset');
      const stat = data[8]!;
      const missionId = view.getBigUint64(9, true);
      const nonce = view.getBigUint64(21, true);
      const expiresAt = view.getBigInt64(29, true);
      if (BigInt(this.nowSeconds()) >= expiresAt) throw new Error('claim expired');
      const key = `${asset.asset}:${missionId}:${nonce}`;
      if (this.receipts.has(key)) throw new Error('receipt already exists');
      this.receipts.add(key);
      asset.credits[stat]! += 1;
    } else {
      throw new Error('unknown instruction');
    }
    const signature = transaction.signatures[0]!.signature!.toString('base64');
    this.applied.push(signature);
    return signature;
  }

  /** The Candy Guard mint plus `register_citizen`, as one step: the buyer pays, the next citizen of the draw is theirs. */
  private applyMint(transaction: Transaction, instruction: TransactionInstruction): string {
    const sale = this.sale_;
    if (!sale || !sale.loaded) throw new Error('no sale');
    const buyer = instruction.keys[0]!.pubkey.toBase58();
    const asset = instruction.keys[1]!.pubkey.toBase58();
    const serial = sale.queue[0];
    if (serial === undefined) throw new Error('sold out');
    if ((sale.minted.get(buyer) ?? 0) >= sale.limit) throw new Error('mint limit reached');
    const balance = this.sol.get(buyer) ?? 0n;
    if (balance < sale.price) throw new Error('not enough SOL');
    this.sol.set(buyer, balance - sale.price);
    sale.queue.shift();
    sale.minted.set(buyer, (sale.minted.get(buyer) ?? 0) + 1);
    const base = this.roster.find((citizen) => citizen.id === serial);
    const scores: [number, number, number] = [base?.intelligence ?? 0, base?.alignment ?? 0, base?.compute ?? 0];
    this.assets.push({ asset, owner: buyer, serial, scores, credits: [0, 0, 0], registered: true });
    const signature = transaction.signatures[0]!.signature!.toString('base64');
    this.applied.push(signature);
    return signature;
  }

  /** A `SendRpc` that lands transactions in this world. */
  sendRpc(): SendRpc & { sent: number; status: SendRpc['status'] } {
    const landed = new Set<string>();
    const rpc = {
      sent: 0,
      latestBlockhash: async () => ({ blockhash: '11111111111111111111111111111111', lastValidBlockHeight: 1n }),
      ownerOf: async (account: string) => (account === UTILITY_MINT ? TOKEN_PROGRAM : null),
      send: async (base64: string) => {
        rpc.sent += 1;
        const signature = this.apply(Buffer.from(base64, 'base64'));
        landed.add(signature);
        return signature;
      },
      status: async (signature: string): Promise<SignatureStatus> => ({
        state: landed.has(signature) ? 'confirmed' : null,
        failed: false,
      }),
    };
    return rpc;
  }
}

/** Signs `message` as `keypair` the way a wallet's `signMessage` does. */
function signMessage(keypair: Keypair, message: Uint8Array): Uint8Array {
  const key = createPrivateKey({
    key: Buffer.concat([Buffer.from('302e020100300506032b657004220420', 'hex'), Buffer.from(keypair.secretKey.subarray(0, 32))]),
    format: 'der',
    type: 'pkcs8',
  });
  return sign(null, Buffer.from(message), key);
}

export interface TestWallet extends WalletSession {
  readonly keypair: Keypair;
  /** Number of prompts the person has seen, by kind. */
  readonly prompts: { message: number; transaction: number };
  /** While true, the person closes every prompt. */
  decline: boolean;
  /** While true, only the message prompt is closed (the sign-in). */
  declineMessages: boolean;
}

export function testWallet(keypair = Keypair.generate()): TestWallet {
  const wallet: TestWallet = {
    keypair,
    address: keypair.publicKey.toBase58(),
    prompts: { message: 0, transaction: 0 },
    decline: false,
    declineMessages: false,
    async signMessage(message) {
      wallet.prompts.message += 1;
      if (wallet.decline || wallet.declineMessages) throw new WalletDeclinedError();
      return signMessage(keypair, message);
    },
    async signTransaction(bytes) {
      wallet.prompts.transaction += 1;
      if (wallet.decline) throw new WalletDeclinedError();
      const transaction = Transaction.from(bytes);
      transaction.partialSign(keypair);
      return new Uint8Array(transaction.serialize({ requireAllSignatures: false, verifySignatures: false }));
    },
  };
  return wallet;
}
