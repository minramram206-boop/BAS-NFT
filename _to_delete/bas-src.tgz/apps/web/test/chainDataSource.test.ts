import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { after, before, describe, it } from 'node:test';

import { loadCitizens } from '@bas/content/server';
import { Authenticator, MemoryStore, MintService, MissionService, createMissionServer, findMission } from '@bas/mission-server';
import { Keypair } from '@solana/web3.js';

import { createChainDataSource } from '../src/lib/data/chain/chainDataSource.ts';
import { createTransactions } from '../src/lib/data/chain/transactions.ts';
import type { ChainDataSource } from '../src/lib/data/chain/types.ts';
import { MISSION_CATALOG } from '../src/lib/data/missionCatalog.ts';
import { MOCK_ANSWERS } from '../src/lib/data/mock/mockSnapshot.ts';
import type { DistrictActionResult, MissionDefinition, StepProof } from '../src/lib/data/types.ts';
import { BASE_COST, DAY, PROGRAM_ID, SEASON_START, UTILITY_MINT, World, testWallet, type FakeSale, type TestWallet } from './chainWorld.ts';

const roster = loadCitizens();
const [A, B, C] = roster.map((citizen) => citizen.id) as [number, number, number];

class Clock {
  now = (SEASON_START + 3_600) * 1000;
  readonly read = (): number => this.now;
  advance(seconds: number): void {
    this.now += seconds * 1000;
  }
}

interface Rig {
  clock: Clock;
  world: World;
  source: ChainDataSource;
  owner: TestWallet;
  asset: { a: string; b: string; c: string };
  network: { serverDown: boolean };
  close: () => Promise<void>;
}

const mission = (id: string): MissionDefinition => {
  const found = MISSION_CATALOG.find((item) => item.id === id);
  assert.ok(found, id);
  return found;
};

interface RigOptions {
  events?: Record<string, { startsAt: number; endsAt: number }>;
  scores?: [number, number, number];
  /** Open a public sale holding the roster citizens that are not minted yet. */
  sale?: Partial<FakeSale>;
}

async function rig(options: RigOptions = {}): Promise<Rig> {
  const clock = new Clock();
  const world = new World(roster, () => Math.floor(clock.now / 1000));
  const owner = testWallet();
  const stranger = testWallet();
  const asset = {
    a: world.add(A, owner.address, options.scores ?? [1, 1, 1], [1, 1, 2]),
    b: world.add(B, stranger.address, [2, 2, 2], [0, 0, 0]),
    // Minted but not registered yet: it exists, with no scores of its own.
    c: world.add(C, owner.address, [0, 0, 0], [0, 0, 0], false),
  };
  world.tokens.set(owner.address, 2_000_000_000n);
  world.sol.set(owner.address, 3_000_000_000n);
  if (options.sale) {
    const queue = roster.map((citizen) => citizen.id).filter((id) => ![A, B, C].includes(id));
    world.sale_ = { queue, total: queue.length, price: 10_000_000n, limit: 1, minted: new Map(), loaded: true, ...options.sale };
  }

  const service = new MissionService({
    programId: PROGRAM_ID,
    authority: Keypair.generate(),
    season: { id: 1, startsAt: SEASON_START, days: 28 },
    ...(options.events ? { events: options.events } : {}),
    store: new MemoryStore(),
    chain: world,
    clock: clock.read,
  });
  const server = createMissionServer({
    service,
    mint: new MintService({ backend: world.mintBackend(), limitPerWallet: 1 }),
    auth: new Authenticator(Buffer.alloc(32, 9)),
    allowedOrigins: [],
    rateLimit: 100_000,
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const network = { serverDown: false };

  const source = createChainDataSource({
    roster,
    reads: world,
    transactions: createTransactions({
      rpc: world.sendRpc(),
      programId: PROGRAM_ID.toBase58(),
      utilityMint: UTILITY_MINT,
      sleep: async () => {},
    }),
    missionApi: {
      baseUrl,
      fetch: (async (...args: Parameters<typeof fetch>) => {
        if (network.serverDown) throw new TypeError('fetch failed');
        return fetch(...args);
      }) as typeof fetch,
    },
    baseTrainingCostAtoms: BASE_COST.toString(),
    mintPriceLamports: '10000000',
    mintLimitPerWallet: 1,
    maxSupply: 100,
    clock: clock.read,
    sleep: async () => {},
  });
  return {
    clock,
    world,
    source,
    owner,
    asset,
    network,
    close: () => new Promise<void>((resolve) => server.close(() => resolve())),
  };
}

function ok(result: DistrictActionResult) {
  assert.ok(result.ok, result.ok ? '' : `refused with ${result.error}`);
  return result.snapshot;
}

function refused(result: DistrictActionResult): string {
  assert.equal(result.ok, false, 'expected a refusal');
  return result.ok ? '' : result.error;
}

/** The proof a player would give for step `index` of a mission. */
function proofFor(missionId: string, index: number): StepProof {
  const step = findMission(missionId)!.steps[index]!;
  if (step.kind === 'goto') return { kind: 'goto' };
  if (step.kind === 'talk') return { kind: 'talk', answer: MOCK_ANSWERS[missionId]![index]! };
  return { kind: 'puzzle', order: Array.from({ length: step.pieces }, (_, position) => position) };
}

/** Plays steps `from` up to (not including) `to` of a mission, leaving the walk time the server asks for. */
async function playSteps(r: Rig, citizenId: number, missionId: string, from: number, to: number): Promise<DistrictActionResult> {
  let last: DistrictActionResult = { ok: true, snapshot: r.source.snapshot() };
  for (let index = from; index < to; index += 1) {
    r.clock.advance(20);
    last = await r.source.advanceMission(citizenId, missionId, proofFor(missionId, index));
    if (!last.ok) return last;
  }
  return last;
}

async function playAll(r: Rig, citizenId: number, missionId: string): Promise<DistrictActionResult> {
  return playSteps(r, citizenId, missionId, 0, findMission(missionId)!.steps.length);
}

describe('reading the district', () => {
  let r: Rig;
  before(async () => {
    r = await rig();
  });
  after(() => r.close());

  it('starts empty and not connected', () => {
    const snapshot = r.source.snapshot();
    assert.equal(r.source.mode, 'chain');
    assert.equal(snapshot.wallet.connected, false);
    assert.deepEqual(snapshot.owned, []);
    assert.deepEqual(snapshot.citizens, []);
  });

  it('shows the citizens on chain with their own scores and credits once a wallet is connected', async () => {
    const snapshot = ok(await r.source.setWallet(r.owner));
    assert.equal(snapshot.wallet.connected, true);
    assert.equal(snapshot.wallet.label, `${r.owner.address.slice(0, 4)}…${r.owner.address.slice(-3)}`);
    assert.equal(snapshot.wallet.tokenAtoms, 2_000_000_000n);
    assert.equal(snapshot.wallet.solLamports, 3_000_000_000n);
    assert.deepEqual(snapshot.citizens.map((citizen) => citizen.id), [A, B, C].sort((x, y) => x - y));
    assert.deepEqual([...snapshot.owned].sort((x, y) => x - y), [A, C].sort((x, y) => x - y));

    const first = snapshot.citizens.find((citizen) => citizen.id === A)!;
    assert.deepEqual([first.intelligence, first.alignment, first.compute, first.registered], [1, 1, 1, true]);
    assert.equal(first.name, roster.find((citizen) => citizen.id === A)!.name);
    assert.deepEqual(snapshot.credits[A], { intelligence: 1, alignment: 1, compute: 2 });

    const waiting = snapshot.citizens.find((citizen) => citizen.id === C)!;
    assert.equal(waiting.registered, false);
    assert.deepEqual(snapshot.credits[C], { intelligence: 0, alignment: 0, compute: 0 });
  });

  it('reports the mint, the season and the missions that can be listed', () => {
    const snapshot = r.source.snapshot();
    assert.equal(snapshot.mint.minted, 3);
    assert.equal(snapshot.mint.maxSupply, 100);
    assert.equal(snapshot.mint.priceLamports, 10_000_000n);
    assert.equal(snapshot.mint.limitPerWallet, 1);
    assert.deepEqual(snapshot.founding, []);
    assert.deepEqual([snapshot.season.number, snapshot.season.day, snapshot.season.length], [1, 1, 28]);
    // The event is not scheduled, so it is not listed.
    assert.deepEqual(
      snapshot.missions.map((item) => item.id),
      MISSION_CATALOG.filter((item) => !item.event).map((item) => item.id),
    );
  });

  it('forgets the citizens of a wallet that disconnects', async () => {
    const snapshot = ok(await r.source.setWallet(null));
    assert.equal(snapshot.wallet.connected, false);
    assert.deepEqual(snapshot.owned, []);
    assert.equal(snapshot.wallet.tokenAtoms, 0n);
    assert.equal(snapshot.citizens.length, 3);
    ok(await r.source.setWallet(r.owner));
  });

  it('follows a citizen that is sold to another wallet', async () => {
    r.world.transfer(r.asset.a, testWallet().address);
    const snapshot = ok(await r.source.refresh!());
    assert.deepEqual(snapshot.owned, [C]);
    r.world.transfer(r.asset.a, r.owner.address);
    ok(await r.source.refresh!());
  });

  it('keeps what it knew when the cluster cannot be reached', async () => {
    r.world.down = true;
    assert.equal(refused(await r.source.refresh!()), 'unavailable');
    assert.equal(r.source.snapshot().citizens.length, 3);
    r.world.down = false;
  });
});

describe('training', () => {
  it('sends upgrade_score, burns the cost and shows the new score and credit', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      const snapshot = ok(await r.source.upgradeScore(A, 'compute'));
      assert.equal(snapshot.citizens.find((citizen) => citizen.id === A)!.compute, 2);
      assert.equal(snapshot.credits[A]!.compute, 1);
      assert.equal(snapshot.wallet.tokenAtoms, 2_000_000_000n - BASE_COST * 2n, 'the cost of raising a score of 1');
      assert.equal(r.owner.prompts.transaction, 1);
      assert.equal(r.world.applied.length, 1);
    } finally {
      await r.close();
    }
  });

  it('refuses before the wallet is asked when a rule is already broken', async () => {
    const r = await rig({ scores: [10, 1, 1] });
    try {
      assert.equal(refused(await r.source.upgradeScore(A, 'compute')), 'not-connected');
      ok(await r.source.setWallet(r.owner));
      assert.equal(refused(await r.source.upgradeScore(B, 'compute')), 'not-owner', 'held by another wallet');
      assert.equal(refused(await r.source.upgradeScore(999, 'compute')), 'not-owner', 'not on chain');
      assert.equal(refused(await r.source.upgradeScore(A, 'intelligence')), 'stat-at-max');

      r.world.find(r.asset.a).credits[2] = 0;
      ok(await r.source.refresh!());
      assert.equal(refused(await r.source.upgradeScore(A, 'compute')), 'no-credit');

      r.world.find(r.asset.a).credits[2] = 1;
      r.world.tokens.set(r.owner.address, BASE_COST);
      ok(await r.source.refresh!());
      assert.equal(refused(await r.source.upgradeScore(A, 'compute')), 'insufficient-balance');
      assert.equal(r.owner.prompts.transaction, 0, 'the wallet was never asked');
    } finally {
      await r.close();
    }
  });

  it('changes nothing when the person closes the wallet request', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      r.owner.decline = true;
      assert.equal(refused(await r.source.upgradeScore(A, 'compute')), 'declined');
      assert.equal(r.world.applied.length, 0);
      assert.equal(r.source.snapshot().citizens.find((citizen) => citizen.id === A)!.compute, 1);
    } finally {
      await r.close();
    }
  });

  it('reports a rejected transaction and reads the cluster again', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      // The tokens leave the wallet between the page's last read and the send.
      r.world.tokens.set(r.owner.address, 0n);
      const state = r.source.snapshot();
      assert.equal(state.wallet.tokenAtoms, 2_000_000_000n);
      assert.equal(refused(await r.source.upgradeScore(A, 'compute')), 'transaction-failed');
      assert.equal(r.source.snapshot().wallet.tokenAtoms, 0n, 'the balance was read again');
    } finally {
      await r.close();
    }
  });
});

describe('missions', () => {
  it('plays a mission to the end, claims the credit on chain and counts it', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      assert.equal(r.owner.prompts.message, 1, 'one sign-in at connect');

      const started = ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      assert.deepEqual(started.missionProgress.streetLamp, { citizenId: A, done: 0, stat: 'compute' });

      const midway = ok(await playSteps(r, A, 'streetLamp', 0, 2));
      assert.equal(midway.missionProgress.streetLamp!.done, 2);
      assert.equal(r.owner.prompts.transaction, 0, 'nothing to sign until the last step');

      const done = ok(await playSteps(r, A, 'streetLamp', 2, 3));
      assert.equal(done.missionProgress.streetLamp, undefined);
      assert.equal(done.credits[A]!.compute, 3, 'the claim landed on chain');
      assert.deepEqual(done.history[A]![0], { day: 1, kind: 'mission', missionId: 'streetLamp', stat: 'compute' });
      assert.equal(r.owner.prompts.transaction, 1);
      assert.equal(r.owner.prompts.message, 1, 'the token was reused');
      assert.deepEqual(done.season.leaderboards.open, [{ citizenId: A, serial: roster.find((c) => c.id === A)!.code, roleKey: roster.find((c) => c.id === A)!.roleKey, points: 100 }]);
    } finally {
      await r.close();
    }
  });

  it('leaves the step open and tells the player when the answer is wrong', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      ok(await r.source.startMission(A, 'lightsOut', 'intelligence'));
      ok(await playSteps(r, A, 'lightsOut', 0, 1));

      r.clock.advance(20);
      assert.equal(refused(await r.source.advanceMission(A, 'lightsOut', { kind: 'talk', answer: 0 })), 'wrong-answer');
      assert.equal(r.source.snapshot().missionProgress.lightsOut!.done, 1);

      ok(await playSteps(r, A, 'lightsOut', 1, 3));
      assert.equal(r.source.snapshot().missionProgress.lightsOut, undefined);
    } finally {
      await r.close();
    }
  });

  it('rejects a puzzle in the wrong order and a proof of the wrong kind', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      ok(await playSteps(r, A, 'streetLamp', 0, 2));
      r.clock.advance(20);
      assert.equal(refused(await r.source.advanceMission(A, 'streetLamp', { kind: 'puzzle', order: [1, 0, 2, 3] })), 'wrong-order');
      assert.equal(refused(await r.source.advanceMission(A, 'streetLamp', { kind: 'goto' })), 'mission-closed');
    } finally {
      await r.close();
    }
  });

  it('keeps the last step open when the person closes the claim request, and claims without a new step', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      ok(await playSteps(r, A, 'streetLamp', 0, 2));

      r.owner.decline = true;
      r.clock.advance(20);
      assert.equal(refused(await r.source.advanceMission(A, 'streetLamp', proofFor('streetLamp', 2))), 'declined');
      assert.equal(r.source.snapshot().missionProgress.streetLamp!.done, 2, 'the puzzle is still the open step');
      assert.equal(r.source.snapshot().credits[A]!.compute, 2);

      r.owner.decline = false;
      const done = ok(await r.source.advanceMission(A, 'streetLamp', proofFor('streetLamp', 2)));
      assert.equal(done.missionProgress.streetLamp, undefined);
      assert.equal(done.credits[A]!.compute, 3);
    } finally {
      await r.close();
    }
  });

  it('picks the claim up again after a reload', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      ok(await playSteps(r, A, 'streetLamp', 0, 2));
      r.owner.decline = true;
      r.clock.advance(20);
      refused(await r.source.advanceMission(A, 'streetLamp', proofFor('streetLamp', 2)));
      r.owner.decline = false;

      // A fresh page: the server still has the session, the new source reads it back.
      ok(await r.source.setWallet(r.owner));
      assert.equal(r.source.snapshot().missionProgress.streetLamp!.done, 2);
      const done = ok(await r.source.advanceMission(A, 'streetLamp', proofFor('streetLamp', 2)));
      assert.equal(done.credits[A]!.compute, 3);
    } finally {
      await r.close();
    }
  });

  it('refuses the same mission twice in one day and a fourth mission', async () => {
    const r = await rig({ scores: [1, 1, 3] });
    try {
      ok(await r.source.setWallet(r.owner));
      for (const [id, stat] of [
        ['streetLamp', 'compute'],
        ['lightsOut', 'intelligence'],
        ['hearthDeliveries', 'alignment'],
      ] as const) {
        ok(await r.source.startMission(A, id, stat));
        ok(await playAll(r, A, id));
      }
      assert.equal(r.source.snapshot().history[A]!.length, 3);
      assert.equal(refused(await r.source.startMission(A, 'streetLamp', 'compute')), 'mission-cooldown');
      assert.equal(refused(await r.source.startMission(A, 'nightPatrol', 'compute')), 'daily-limit');

      r.clock.advance(DAY);
      ok(await r.source.refresh!());
      assert.equal(r.source.snapshot().season.day, 2);
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
    } finally {
      await r.close();
    }
  });

  it('asks the server for the rules it cannot check itself', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      assert.equal(refused(await r.source.startMission(A, 'nightPatrol', 'compute')), 'district-locked');
      assert.equal(refused(await r.source.startMission(B, 'streetLamp', 'compute')), 'not-owner');
      assert.equal(refused(await r.source.startMission(A, 'streetLamp', 'intelligence')), 'invalid-stat');

      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      assert.equal(refused(await r.source.startMission(A, 'lightsOut', 'intelligence')), 'citizen-busy');
    } finally {
      await r.close();
    }
  });

  it('refuses the claim once the season is over', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      ok(await playSteps(r, A, 'streetLamp', 0, 2));
      r.clock.advance(28 * DAY);
      assert.equal(refused(await r.source.advanceMission(A, 'streetLamp', proofFor('streetLamp', 2))), 'season-closed');
      assert.equal(r.owner.prompts.transaction, 0);
      assert.equal(refused(await r.source.startMission(B, 'streetLamp', 'compute')), 'not-owner');
    } finally {
      await r.close();
    }
  });

  it('abandons a mission', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      const snapshot = ok(await r.source.abandonMission('streetLamp'));
      assert.deepEqual(snapshot.missionProgress, {});
      ok(await r.source.startMission(A, 'lightsOut', 'intelligence'));
      assert.equal(refused(await r.source.abandonMission('streetLamp')), 'mission-closed');
    } finally {
      await r.close();
    }
  });

  it('asks again for the sign-in when the person closed it at connect', async () => {
    const r = await rig();
    try {
      r.owner.declineMessages = true;
      const snapshot = ok(await r.source.setWallet(r.owner));
      assert.deepEqual(snapshot.missionProgress, {}, 'no mission data without a sign-in');
      ok(await r.source.refresh!());
      assert.equal(r.owner.prompts.message, 1, 'a refresh does not ask again on its own');

      assert.equal(refused(await r.source.startMission(A, 'streetLamp', 'compute')), 'declined');
      assert.equal(r.owner.prompts.message, 2);
      r.owner.declineMessages = false;
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      assert.equal(r.owner.prompts.message, 3);
    } finally {
      await r.close();
    }
  });

  it('says so when the mission server is down and keeps the district on screen', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      r.network.serverDown = true;
      assert.equal(refused(await r.source.startMission(A, 'streetLamp', 'compute')), 'unavailable');
      const snapshot = ok(await r.source.refresh!());
      assert.equal(snapshot.citizens.length, 3, 'the cluster part still loads');
      assert.equal(snapshot.season.length, 28, 'the last known season stays');
      r.network.serverDown = false;
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
    } finally {
      await r.close();
    }
  });

  it('cannot mint from here yet', async () => {
    const r = await rig();
    try {
      ok(await r.source.setWallet(r.owner));
      assert.equal(refused(await r.source.mintCitizen()), 'unavailable');
    } finally {
      await r.close();
    }
  });
});

describe('district events', () => {
  it('lists an event that is coming, lets it start inside its window and hides it once it is over', async () => {
    const start = SEASON_START + 3_600;
    const r = await rig({ events: { blackoutNight: { startsAt: start + 2 * DAY, endsAt: start + 3 * DAY } } });
    try {
      ok(await r.source.setWallet(r.owner));
      const event = () => r.source.snapshot().missions.find((item) => item.id === 'blackoutNight');
      assert.equal(event()!.opensInHours, 48);
      assert.equal(refused(await r.source.startMission(A, 'blackoutNight', 'compute')), 'mission-closed');

      r.clock.advance(2 * DAY + 60);
      ok(await r.source.refresh!());
      assert.equal(event()!.opensInHours, undefined);
      assert.equal(event()!.event, true);
      ok(await r.source.startMission(A, 'blackoutNight', 'compute'));
      ok(await playAll(r, A, 'blackoutNight'));
      assert.equal(r.source.snapshot().season.leaderboards.open![0]!.points, 150);

      r.clock.advance(2 * DAY);
      ok(await r.source.refresh!());
      assert.equal(event(), undefined);
    } finally {
      await r.close();
    }
  });
});

describe('season standings', () => {
  it('ranks citizens by points and files each one under its bracket', async () => {
    const r = await rig({ scores: [1, 1, 5] });
    try {
      ok(await r.source.setWallet(r.owner));
      ok(await r.source.startMission(A, 'streetLamp', 'compute'));
      ok(await playAll(r, A, 'streetLamp'));
      const { pools, leaderboards } = r.source.snapshot().season;
      assert.equal(leaderboards.skilled?.[0]?.citizenId, A, 'a highest stat of 5 is the skilled bracket');
      assert.equal(leaderboards.rookie, undefined);
      assert.equal(pools.find((pool) => pool.id === 'skilled')!.validEntries, 1);
      assert.equal(pools.find((pool) => pool.id === 'open')!.validEntries, 1);
      assert.equal(pools.find((pool) => pool.id === 'master')!.validEntries, 0);
    } finally {
      await r.close();
    }
  });
});

describe('minting', () => {
  /** A wallet with SOL and no citizen, connected to a rig that has a sale. */
  async function buyerRig(sale: RigOptions['sale'] = {}, sol = 1_000_000_000n) {
    const r = await rig({ sale });
    const buyer = testWallet();
    r.world.sol.set(buyer.address, sol);
    return { r, buyer };
  }

  it('reads the real supply from the Candy Machine instead of the manifest', async () => {
    const { r, buyer } = await buyerRig();
    try {
      const snapshot = ok(await r.source.setWallet(buyer));
      assert.equal(snapshot.mint.maxSupply, 7, 'the machine holds 7 citizens, not the 100 of the manifest');
      assert.equal(snapshot.mint.minted, 0, 'minted comes from the machine, not from counting what the page can see');
      assert.equal(snapshot.mint.mintedByWallet, 0);
    } finally {
      await r.close();
    }
  });

  it('pays, mints and registers in one signature, then shows the citizen it drew', async () => {
    const { r, buyer } = await buyerRig();
    try {
      ok(await r.source.setWallet(buyer));
      const next = r.world.sale_!.queue[0]!;
      const result = await r.source.mintCitizen();
      assert.ok(result.ok, result.ok ? '' : result.error);
      if (!result.ok) return;
      assert.equal(result.citizenId, next, 'the citizen is the one the machine drew');
      assert.deepEqual(result.snapshot.owned, [next]);
      const citizen = result.snapshot.citizens.find((item) => item.id === next)!;
      assert.equal(citizen.registered, true, 'registered by the same transaction');
      assert.equal(result.snapshot.wallet.solLamports, 1_000_000_000n - 10_000_000n);
      assert.equal(result.snapshot.mint.minted, 1);
      assert.equal(result.snapshot.mint.mintedByWallet, 1);
      assert.equal(buyer.prompts.transaction, 1, 'one transaction to approve');
      assert.equal(r.world.built.length, 1);
    } finally {
      await r.close();
    }
  });

  it('stops a second mint from the same wallet before the wallet is asked', async () => {
    const { r, buyer } = await buyerRig();
    try {
      ok(await r.source.setWallet(buyer));
      assert.ok((await r.source.mintCitizen()).ok);
      assert.equal(refused(await r.source.mintCitizen()), 'mint-limit');
      assert.equal(buyer.prompts.transaction, 1);
      assert.equal(r.world.built.length, 1, 'the server was not asked for another transaction');
    } finally {
      await r.close();
    }
  });

  it('refuses a sold-out sale, a wallet without SOL and a visitor without a wallet', async () => {
    const soldOut = await buyerRig({ queue: [], total: 7 });
    try {
      ok(await soldOut.r.source.setWallet(soldOut.buyer));
      assert.equal(refused(await soldOut.r.source.mintCitizen()), 'sold-out');
    } finally {
      await soldOut.r.close();
    }

    const poor = await buyerRig({}, 5_000_000n);
    try {
      ok(await poor.r.source.setWallet(poor.buyer));
      assert.equal(refused(await poor.r.source.mintCitizen()), 'insufficient-sol');
      assert.equal(poor.buyer.prompts.transaction, 0);
    } finally {
      await poor.r.close();
    }

    const visitor = await buyerRig();
    try {
      assert.equal(refused(await visitor.r.source.mintCitizen()), 'not-connected');
    } finally {
      await visitor.r.close();
    }
  });

  it('changes nothing when the person closes the wallet request', async () => {
    const { r, buyer } = await buyerRig();
    try {
      ok(await r.source.setWallet(buyer));
      buyer.decline = true;
      assert.equal(refused(await r.source.mintCitizen()), 'declined');
      assert.equal(r.source.snapshot().mint.minted, 0);
      assert.equal(r.world.applied.length, 0);
    } finally {
      await r.close();
    }
  });

  it('reports unavailable while the machine is not fully loaded, without a wallet prompt for the transaction', async () => {
    const { r, buyer } = await buyerRig({ loaded: false });
    try {
      ok(await r.source.setWallet(buyer));
      assert.equal(refused(await r.source.mintCitizen()), 'unavailable');
      assert.equal(buyer.prompts.transaction, 0);
    } finally {
      await r.close();
    }
  });

  it('reports a mint the cluster refuses after the signature, and nothing is paid', async () => {
    const { r, buyer } = await buyerRig();
    try {
      ok(await r.source.setWallet(buyer));
      // The cluster counts this wallet as at its limit although the page did not know yet.
      r.world.sale_!.limit = 0;
      assert.equal(refused(await r.source.mintCitizen()), 'transaction-failed');
      assert.equal(r.source.snapshot().mint.minted, 0);
      assert.equal(r.source.snapshot().wallet.solLamports, 1_000_000_000n, 'nothing was paid');
    } finally {
      await r.close();
    }
  });
});
