import type { CitizenStateOnChain } from '@bas/chain-client/browser';
import type { StatKey } from '@bas/content';
import type { DistrictActionResult, DistrictDataSource, StepProof } from '../types';

/**
 * Ports of the chain data source. Everything that touches the network or a
 * wallet sits behind one of these, so the rules in `chainDataSource.ts` run
 * the same against a real cluster and against the fakes in the tests.
 */

/** A citizen asset of the collection, joined with its registered state. */
export interface ChainCitizen {
  /** Address of the Core asset. */
  readonly asset: string;
  /** Current holder of the asset. */
  readonly owner: string;
  /** Serial from the metadata file name; `null` when the file does not follow the naming rule. */
  readonly serial: number | null;
  /** `null` until `register_citizen` has run for this asset. */
  readonly state: CitizenStateOnChain | null;
}

export interface Balances {
  readonly solLamports: bigint;
  /** Utility token in atoms; zero when the wallet has no token account. */
  readonly tokenAtoms: bigint;
}

/** The public sale as the Candy Machine account and the wallet's mint counter show it. */
export interface SaleReading {
  /** Citizens the machine was created with: the real supply. */
  readonly itemsAvailable: number;
  /** Citizens minted so far. */
  readonly itemsRedeemed: number;
  /** Mints this wallet made from the sale; zero without a wallet. */
  readonly mintedByWallet: number;
}

/** Reads of the cluster. */
export interface DistrictReads {
  /** Every asset of the official collection with its district state. */
  citizens(): Promise<readonly ChainCitizen[]>;
  balances(owner: string): Promise<Balances>;
  /** The Candy Machine and the wallet's counter, or `null` when the sale is not set up on this cluster. */
  sale(wallet: string | null): Promise<SaleReading | null>;
}

/** What a connected wallet can do. Both calls may be refused by the person. */
export interface WalletSession {
  readonly address: string;
  signMessage(message: Uint8Array): Promise<Uint8Array>;
  /** Takes and returns a serialized transaction; the wallet adds its signature. */
  signTransaction(transaction: Uint8Array): Promise<Uint8Array>;
}

/** Thrown by a `WalletSession` when the person closes the request. */
export class WalletDeclinedError extends Error {
  constructor(message = 'The wallet request was declined') {
    super(message);
    this.name = 'WalletDeclinedError';
  }
}

/** Builds and sends the transactions the program accepts from the owner. */
export interface DistrictTransactions {
  /** An unsigned `upgrade_score` transaction paid by `owner`. */
  buildUpgradeScore(input: { owner: string; asset: string; stat: StatKey }): Promise<Uint8Array>;
  /** Sends a signed transaction and resolves with its signature once it is confirmed. */
  send(signed: Uint8Array): Promise<string>;
}

/** The data source plus what the app needs to connect a wallet and re-read the cluster. */
export interface ChainDataSource extends DistrictDataSource {
  readonly mode: 'chain';
  /** Connect (or, with `null`, disconnect) a wallet and read its citizens. */
  setWallet(session: WalletSession | null): Promise<DistrictActionResult>;
  refresh(): Promise<DistrictActionResult>;
}

export type { StepProof };
