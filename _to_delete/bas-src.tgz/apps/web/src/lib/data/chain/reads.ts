import {
  CITIZEN_STATE_DISCRIMINATOR,
  CITIZEN_STATE_LAYOUT,
  CORE_ASSET_LAYOUT,
  CORE_CANDY_GUARD_PROGRAM_ID,
  CORE_CANDY_MACHINE_PROGRAM_ID,
  MINT_LIMIT_ID,
  MPL_CORE_PROGRAM_ID,
  associatedTokenAddress,
  candyGuardAddress,
  decodeCandyMachine,
  decodeCitizenState,
  decodeCoreAsset,
  decodeMintCounter,
  decodeTokenAccountAmount,
  mintCounterAddress,
  serialFromMetadataUri,
} from '@bas/chain-client/browser';
import { address, createSolanaRpc, getAddressEncoder, getBase58Decoder, getBase64Encoder, type Address } from '@solana/kit';
import type { Balances, ChainCitizen, DistrictReads, SaleReading } from './types';

/**
 * Reads of the cluster through `@solana/kit`. The RPC is wrapped in a small
 * interface so the decoding and joining can be tested without a network.
 */

export interface RawAccount {
  readonly owner: string;
  readonly data: Uint8Array;
}

export interface ProgramFilter {
  /** Raw bytes that must sit at `offset`. */
  readonly offset: number;
  readonly bytes: Uint8Array;
}

export interface ReadRpc {
  programAccounts(program: string, filters: readonly ProgramFilter[], dataSize?: number): Promise<readonly (RawAccount & { address: string })[]>;
  account(address: string): Promise<RawAccount | null>;
  balance(address: string): Promise<bigint>;
}

export interface ReadsOptions {
  readonly rpc: ReadRpc;
  readonly programId: string;
  /** Official Core collection. */
  readonly collection: string;
  readonly utilityMint: string;
  /** Core Candy Machine of the public sale; without it `sale()` reports no sale. */
  readonly candyMachine?: string;
}

const addressToBytes = (value: string): Uint8Array => new Uint8Array(getAddressEncoder().encode(address(value)));

/** `ReadRpc` over a JSON-RPC endpoint. */
export function kitReadRpc(url: string): ReadRpc {
  const rpc = createSolanaRpc(url);
  const base64 = getBase64Encoder();
  const decode = (data: readonly [string, string]): Uint8Array => new Uint8Array(base64.encode(data[0]));
  const base58 = getBase58Decoder();
  return {
    async programAccounts(program, filters, dataSize) {
      const accounts = await rpc
        .getProgramAccounts(address(program), {
          commitment: 'confirmed',
          encoding: 'base64',
          filters: [
            ...(dataSize === undefined ? [] : [{ dataSize: BigInt(dataSize) }]),
            ...filters.map((filter) => ({
              memcmp: {
                offset: BigInt(filter.offset),
                bytes: base58.decode(filter.bytes) as never,
                encoding: 'base58' as const,
              },
            })),
          ],
        })
        .send();
      return (accounts as readonly { pubkey: string; account: { owner: string; data: readonly [string, string] } }[]).map(
        (entry) => ({ address: entry.pubkey, owner: entry.account.owner, data: decode(entry.account.data) }),
      );
    },
    async account(target) {
      const { value } = await rpc.getAccountInfo(address(target), { commitment: 'confirmed', encoding: 'base64' }).send();
      return value ? { owner: value.owner, data: decode(value.data as unknown as readonly [string, string]) } : null;
    },
    async balance(target) {
      return (await rpc.getBalance(address(target), { commitment: 'confirmed' }).send()).value;
    },
  };
}

export function createReads(options: ReadsOptions): DistrictReads {
  const { rpc, programId, collection, utilityMint, candyMachine } = options;
  let tokenProgram: Promise<Address> | undefined;

  const mintProgram = (): Promise<Address> => {
    tokenProgram ??= rpc.account(utilityMint).then((mint) => {
      if (!mint) throw new Error(`the utility token mint ${utilityMint} does not exist on this cluster`);
      return address(mint.owner);
    });
    return tokenProgram;
  };

  return {
    async citizens() {
      const [assets, states] = await Promise.all([
        rpc.programAccounts(MPL_CORE_PROGRAM_ID, [{ offset: CORE_ASSET_LAYOUT.collectionOffset, bytes: addressToBytes(collection) }]),
        rpc.programAccounts(
          programId,
          [{ offset: 0, bytes: CITIZEN_STATE_DISCRIMINATOR }],
          CITIZEN_STATE_LAYOUT.length,
        ),
      ]);

      const stateOf = new Map<string, NonNullable<ReturnType<typeof decodeCitizenState>>>();
      for (const entry of states) {
        const state = decodeCitizenState(entry.data);
        if (state) stateOf.set(state.asset, state);
      }

      const citizens: ChainCitizen[] = [];
      for (const entry of assets) {
        const asset = decodeCoreAsset(entry.data);
        // The filter already matches the collection; this guards against a different account kind with the same bytes.
        if (!asset || asset.collection !== collection) continue;
        citizens.push({
          asset: entry.address,
          owner: asset.owner,
          serial: serialFromMetadataUri(asset.uri) ?? null,
          state: stateOf.get(entry.address) ?? null,
        });
      }
      return citizens;
    },

    async sale(wallet): Promise<SaleReading | null> {
      if (!candyMachine) return null;
      const machine = await rpc.account(candyMachine);
      if (!machine || machine.owner !== CORE_CANDY_MACHINE_PROGRAM_ID) return null;
      const decoded = decodeCandyMachine(machine.data);
      if (!decoded) return null;

      let mintedByWallet = 0;
      if (wallet) {
        const counter = await mintCounterAddress({
          id: MINT_LIMIT_ID,
          user: address(wallet),
          candyMachine: address(candyMachine),
          candyGuard: await candyGuardAddress(address(candyMachine)),
        });
        const account = await rpc.account(counter);
        // The counter is only written by the guard program; anything else at that address is not a count.
        if (account && account.owner === CORE_CANDY_GUARD_PROGRAM_ID) mintedByWallet = decodeMintCounter(account.data) ?? 0;
      }
      return { itemsAvailable: decoded.itemsAvailable, itemsRedeemed: decoded.itemsRedeemed, mintedByWallet };
    },

    async balances(owner): Promise<Balances> {
      const program = await mintProgram();
      const token = await associatedTokenAddress(address(owner), address(utilityMint), program);
      const [solLamports, account] = await Promise.all([rpc.balance(owner), rpc.account(token)]);
      const tokenAtoms = account ? (decodeTokenAccountAmount(account.data, address(utilityMint), address(owner)) ?? 0n) : 0n;
      return { solLamports, tokenAtoms };
    },
  };
}
