import { upgradeScoreInstruction } from '@bas/chain-client/browser';
import {
  address,
  appendTransactionMessageInstruction,
  compileTransaction,
  createSolanaRpc,
  createTransactionMessage,
  getBase64Decoder,
  getTransactionEncoder,
  pipe,
  setTransactionMessageFeePayer,
  setTransactionMessageLifetimeUsingBlockhash,
  type Address,
  type Blockhash,
  type Signature,
} from '@solana/kit';
import type { DistrictTransactions } from './types';

/** The transaction was sent but the cluster rejected it, or it never showed up. */
export class TransactionFailedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'TransactionFailedError';
  }
}

export interface SignatureStatus {
  /** `null` while the cluster has not seen the transaction. */
  readonly state: 'processed' | 'confirmed' | 'finalized' | null;
  readonly failed: boolean;
}

/** The RPC calls a transaction needs, behind an interface so tests can replace them. */
export interface SendRpc {
  latestBlockhash(): Promise<{ blockhash: string; lastValidBlockHeight: bigint }>;
  /** Program that owns the account (used to tell SPL Token from Token-2022), or `null` when it does not exist. */
  ownerOf(account: string): Promise<string | null>;
  send(base64Transaction: string): Promise<string>;
  status(signature: string): Promise<SignatureStatus>;
}

export function kitSendRpc(url: string): SendRpc {
  const rpc = createSolanaRpc(url);
  return {
    async latestBlockhash() {
      return (await rpc.getLatestBlockhash({ commitment: 'confirmed' }).send()).value;
    },
    async ownerOf(account) {
      const { value } = await rpc.getAccountInfo(address(account), { encoding: 'base64' }).send();
      return value ? value.owner : null;
    },
    async send(base64Transaction) {
      return rpc
        .sendTransaction(base64Transaction as never, { encoding: 'base64', preflightCommitment: 'confirmed' })
        .send();
    },
    async status(signature) {
      const { value } = await rpc.getSignatureStatuses([signature as Signature]).send();
      const entry = value[0];
      if (!entry) return { state: null, failed: false };
      return { state: entry.confirmationStatus ?? 'processed', failed: entry.err !== null };
    },
  };
}

export interface TransactionsOptions {
  readonly rpc: SendRpc;
  readonly programId: string;
  readonly utilityMint: string;
  /** Milliseconds between status checks. */
  readonly pollMs?: number;
  /** Milliseconds to wait for a confirmation before giving up. */
  readonly timeoutMs?: number;
  readonly sleep?: (ms: number) => Promise<void>;
}

export function createTransactions(options: TransactionsOptions): DistrictTransactions {
  const { rpc, programId, utilityMint } = options;
  const pollMs = options.pollMs ?? 1_000;
  const timeoutMs = options.timeoutMs ?? 60_000;
  const sleep = options.sleep ?? ((ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms)));
  const encoder = getTransactionEncoder();
  let tokenProgram: Promise<Address> | undefined;

  const mintProgram = (): Promise<Address> => {
    tokenProgram ??= rpc.ownerOf(utilityMint).then((owner) => {
      if (!owner) throw new TransactionFailedError(`the utility token mint ${utilityMint} does not exist on this cluster`);
      return address(owner);
    });
    return tokenProgram;
  };

  return {
    async buildUpgradeScore({ owner, asset, stat }) {
      const [instruction, { blockhash, lastValidBlockHeight }] = await Promise.all([
        mintProgram().then((program) =>
          upgradeScoreInstruction({
            programId: address(programId),
            owner: address(owner),
            asset: address(asset),
            utilityMint: address(utilityMint),
            tokenProgram: program,
            stat,
          }),
        ),
        rpc.latestBlockhash(),
      ]);
      const message = pipe(
        createTransactionMessage({ version: 'legacy' }),
        (m) => setTransactionMessageFeePayer(address(owner), m),
        (m) =>
          setTransactionMessageLifetimeUsingBlockhash({ blockhash: blockhash as Blockhash, lastValidBlockHeight }, m),
        (m) => appendTransactionMessageInstruction(instruction, m),
      );
      return new Uint8Array(encoder.encode(compileTransaction(message)));
    },

    async send(signed) {
      let signature: string;
      try {
        signature = await rpc.send(getBase64Decoder().decode(signed));
      } catch (error) {
        // The cluster checks the transaction before it takes it (preflight), so this is a refusal, not a lost link.
        throw new TransactionFailedError(error instanceof Error ? error.message : 'the cluster refused the transaction');
      }
      const deadline = Date.now() + timeoutMs;
      while (Date.now() < deadline) {
        const { state, failed } = await rpc.status(signature);
        if (failed) throw new TransactionFailedError('the cluster rejected the transaction');
        if (state === 'confirmed' || state === 'finalized') return signature;
        await sleep(pollMs);
      }
      throw new TransactionFailedError('the transaction was not confirmed in time');
    },
  };
}
