import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { RateLimiter, applyCors, readJsonBody, sendJson } from '@bas/server-kit';
import type { StatName } from './catalog.js';
import { Authenticator } from './auth.js';
import { MissionError } from './errors.js';
import type { MintService } from './mint.js';
import { parseProof } from './rules.js';
import type { MissionService } from './service.js';

const MAX_BODY_BYTES = 4_096;
const STATS: readonly string[] = ['intelligence', 'alignment', 'compute'];

export interface HttpOptions {
  readonly service: MissionService;
  readonly auth: Authenticator;
  /** The public sale. Without it `/mint/prepare` answers `unavailable`. */
  readonly mint?: MintService;
  /** Origins of the web app; requests from others get no CORS headers. */
  readonly allowedOrigins: readonly string[];
  /** Requests per minute per client address. */
  readonly rateLimit?: number;
  readonly clock?: () => number;
}

type Body = Record<string, unknown>;

const readBody = (request: IncomingMessage): Promise<Body> =>
  readJsonBody(request, MAX_BODY_BYTES, (message) => new MissionError('bad-request', message));

function text(body: Body, key: string): string {
  const value = body[key];
  if (typeof value !== 'string' || value.length === 0 || value.length > 200) {
    throw new MissionError('bad-request', `${key} is missing`);
  }
  return value;
}

function stat(body: Body): StatName {
  const value = body.stat;
  if (typeof value !== 'string' || !STATS.includes(value)) throw new MissionError('invalid-stat');
  return value as StatName;
}

/** JSON API of the mission server. */
export function createMissionServer(options: HttpOptions): Server {
  const { service, auth } = options;
  const limiter = new RateLimiter(options.rateLimit ?? 120, options.clock ?? Date.now);

  const send = sendJson;

  const route = async (request: IncomingMessage, url: URL): Promise<{ status: number; payload: unknown }> => {
    const method = request.method ?? 'GET';
    const path = url.pathname;
    const bearer = request.headers.authorization?.replace(/^Bearer /, '');

    if (method === 'GET' && path === '/health') return { status: 200, payload: { ok: true } };

    if (method === 'GET' && path === '/season') return { status: 200, payload: service.season() };

    if (method === 'GET' && path === '/season/standings') {
      return { status: 200, payload: { standings: await service.standings() } };
    }

    if (method === 'POST' && path === '/auth/challenge') {
      const body = await readBody(request);
      const challenge = auth.challenge(text(body, 'wallet'));
      return { status: 200, payload: { nonce: challenge.nonce, message: challenge.message } };
    }

    if (method === 'POST' && path === '/auth/verify') {
      const body = await readBody(request);
      const signature = Buffer.from(text(body, 'signature'), 'base64');
      return { status: 200, payload: auth.redeem(text(body, 'wallet'), text(body, 'nonce'), signature) };
    }

    if (method === 'POST' && path === '/mint/prepare') {
      const wallet = auth.wallet(bearer);
      if (!options.mint) throw new MissionError('unavailable', 'the sale is not configured');
      return { status: 200, payload: await options.mint.prepare(wallet) };
    }

    const match = /^\/citizens\/([1-9A-HJ-NP-Za-km-z]{32,44})\/missions(?:\/([a-z]+))?$/.exec(path);
    if (!match) throw new MissionError('bad-request', 'unknown route');
    const asset = match[1] as string;
    const action = match[2];
    const wallet = auth.wallet(bearer);

    if (method === 'GET' && action === undefined) {
      return { status: 200, payload: await service.status(wallet, asset) };
    }
    if (method !== 'POST' || action === undefined) throw new MissionError('bad-request', 'unknown route');

    const body = await readBody(request);
    switch (action) {
      case 'start':
        return { status: 200, payload: await service.start(wallet, asset, text(body, 'missionId'), stat(body)) };
      case 'step': {
        const proof = parseProof(body.proof);
        if (!proof) throw new MissionError('bad-request', 'proof is not valid');
        return { status: 200, payload: await service.step(wallet, asset, text(body, 'missionId'), proof) };
      }
      case 'claim':
        return { status: 200, payload: await service.claim(wallet, asset, text(body, 'missionId')) };
      case 'confirm':
        return { status: 200, payload: await service.confirm(wallet, asset, text(body, 'missionId')) };
      case 'abandon':
        return { status: 200, payload: await service.abandon(wallet, asset) };
      default:
        throw new MissionError('bad-request', 'unknown route');
    }
  };

  return createServer((request, response) => {
    applyCors(request, response, options.allowedOrigins);
    if (request.method === 'OPTIONS') {
      response.writeHead(204).end();
      return;
    }

    void (async () => {
      try {
        if (!limiter.allow(request.socket.remoteAddress ?? 'unknown')) throw new MissionError('rate-limited');
        const url = new URL(request.url ?? '/', 'http://localhost');
        const { status, payload } = await route(request, url);
        send(response, status, payload);
      } catch (error) {
        if (error instanceof MissionError) {
          send(response, error.status, { error: error.code, message: error.message });
          return;
        }
        // Chain or disk trouble: say so without leaking the cause.
        console.error('[mission-server]', error);
        send(response, 503, { error: 'unavailable', message: 'The server could not finish the request.' });
      }
    })();
  });
}
