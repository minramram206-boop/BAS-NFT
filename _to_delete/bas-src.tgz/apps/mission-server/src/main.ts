import { MINT_LIMIT_ID, createMintBackend } from '@bas/metaplex-client';
import { Authenticator } from './auth.js';
import { RpcChainReader } from './chain.js';
import { loadConfig } from './config.js';
import { createMissionServer } from './http.js';
import { MintService } from './mint.js';
import { MissionService } from './service.js';
import { FileStore } from './store.js';
import { openUpkeep } from './upkeep.js';

const config = loadConfig();

// Confirmed missions become lines in the citizen's public history, written by the chat worker.
const upkeep = await openUpkeep(config.redisUrl);

const service = new MissionService({
  programId: config.programId,
  authority: config.authority,
  season: config.season,
  events: config.events,
  store: new FileStore(config.storeFile),
  chain: new RpcChainReader(config.network.rpcUrl, { programId: config.programId, collection: config.collection }),
  ...(upkeep
    ? {
        onHistory: (event) =>
          upkeep.enqueuePublicLine(event).catch((error: unknown) => {
            console.error(`[mission-server] could not queue a history line: ${error instanceof Error ? error.message : String(error)}`);
          }),
      }
    : {}),
});

const { network, mint } = config;
const sale = mint
  ? new MintService({
      backend: createMintBackend({
        rpcUrl: network.rpcUrl,
        programId: network.districtProgramId,
        approvedTemplateId: network.approvedTemplateId,
        candyMachine: network.candyMachine,
        collection: network.coreCollection,
        treasury: network.solTreasury,
        mintLimitId: MINT_LIMIT_ID,
        mintSecretKey: mint.signer.secretKey,
      }),
      limitPerWallet: network.mintLimitPerWallet,
      ...(mint.opensAt === undefined ? {} : { opensAt: mint.opensAt }),
    })
  : undefined;

createMissionServer({
  ...(sale ? { mint: sale } : {}),
  service,
  auth: new Authenticator(config.tokenSecret),
  allowedOrigins: config.allowedOrigins,
}).listen(config.port, () => {
  console.log(`[mission-server] ${config.network.cluster} on port ${config.port}`);
});
